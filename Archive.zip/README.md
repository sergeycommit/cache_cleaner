# 🎉 Cache Cleaner Installed

Click the puzzle piece 🧩 (1) in the top right of your browser. Then, click<br>
the little pin 📌 (2) next to the extension:

![Step 1](images/wp1.png)

Open the extension (3) on any page to start using Cache Cleaner:

![Step 2](images/wp2.png)
